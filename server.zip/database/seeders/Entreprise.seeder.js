let entrepriveData = [];
entrepriveData.push({
  id: "GPHARMA_0001",
  nom_entreprise: "Gpharma@2.0.0",
  adresse: "Mon Adresse",
  contact: "+261 xx xx xxx xx",
  email: "email@gmail.com",
  nif: "xxxx xxxx xxxx xxxx",
  stat: "xxxx xxxx xxxx xxxx",
  website: "www.gpharma@200.mg",
});

module.exports = entrepriveData;
